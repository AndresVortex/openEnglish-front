export const types = {

    //movies
    getMovies: "[Movies] Get movies",
    setMovies: "[Movies] Set Movies",

    //UI
    setMessage: '[UI] set message',
    loading: '[UI] Loading',
    loaded: '[UI] loaded',
    setError: '[UI] set error',

    //filter
    setFilter: '[filter] set filter'
}